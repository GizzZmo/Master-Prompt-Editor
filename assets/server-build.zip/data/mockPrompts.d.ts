import { Prompt } from '../../../src/types/prompt';
export declare const mockPrompts: Prompt[];
