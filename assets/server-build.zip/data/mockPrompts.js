"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mockPrompts = void 0;
const mockPromptVersions = [
    {
        id: 'v1',
        promptId: 'p1',
        version: '1.0',
        content: 'Initial version of the creative writing prompt.',
        createdAt: new Date().toISOString(),
        metadata: { author: 'Admin' }
    },
    {
        id: 'v2',
        promptId: 'p2',
        version: '1.0',
        content: 'Initial version of the technical explainer.',
        createdAt: new Date().toISOString(),
        metadata: { complexity: 'Beginner' }
    }
];
exports.mockPrompts = [
    {
        id: 'p1',
        name: 'Creative Writing Assistant',
        description: 'Helps users brainstorm story ideas.',
        tags: ['creative', 'writing', 'assistant'],
        content: 'Initial version of the creative writing prompt.',
        version: '1.0',
        versions: mockPromptVersions.filter(v => v.promptId === 'p1')
    },
    {
        id: 'p2',
        name: 'Technical Explainer',
        description: 'Explains complex topics simply.',
        tags: ['technical', 'explainer', 'code'],
        content: 'Initial version of the technical explainer.',
        version: '1.0',
        versions: mockPromptVersions.filter(v => v.promptId === 'p2')
    }
];
