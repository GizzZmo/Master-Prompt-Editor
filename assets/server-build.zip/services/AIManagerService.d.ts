interface AIResult {
    success: boolean;
    data: unknown;
}
interface AIConfig {
    model?: string;
    temperature?: number;
}
export declare class AIManager {
    /**
     * Generates content based on a prompt and configuration.
     */
    generateContent(prompt: string, config: AIConfig): Promise<AIResult>;
    /**
     * Analyzes content.
     */
    analyzeContent(data: unknown): Promise<AIResult>;
    /**
     * Summarizes content.
     */
    summarizeContent(text: string): Promise<AIResult>;
}
export {};
