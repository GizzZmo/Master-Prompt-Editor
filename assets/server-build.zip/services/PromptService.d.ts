import { Prompt, PromptVersion } from '../../../src/types/prompt';
export declare class PromptService {
    getAllPrompts(): Promise<Prompt[]>;
    getPromptById(id: string): Promise<Prompt | undefined>;
    createPrompt(data: Omit<Prompt, 'id' | 'version'>): Promise<Prompt>;
    addPromptVersion(promptId: string, content: string): Promise<PromptVersion>;
    rollbackPromptToVersion(promptId: string, versionId: string): Promise<Prompt | null>;
    updatePromptMetadata(promptId: string, metadata: Partial<Prompt>): Promise<Prompt | null>;
    deletePrompt(promptId: string): Promise<{
        success: boolean;
    }>;
}
