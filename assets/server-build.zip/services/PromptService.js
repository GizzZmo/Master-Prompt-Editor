"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PromptService = void 0;
// A mock database for demonstration purposes
const mockPrompts = [];
const mockVersions = [];
class PromptService {
    async getAllPrompts() {
        return mockPrompts;
    }
    async getPromptById(id) {
        return mockPrompts.find(p => p.id === id);
    }
    // FIX: Added missing 'createPrompt' method
    async createPrompt(data) {
        const newPrompt = {
            id: `prompt_${Date.now()}`,
            version: '1.0',
            ...data,
        };
        mockPrompts.push(newPrompt);
        return newPrompt;
    }
    // FIX: Added missing 'addPromptVersion' method
    async addPromptVersion(promptId, content) {
        const newVersion = {
            id: `v_${Date.now()}`,
            promptId,
            version: (Math.random() + 1).toString().substring(2, 5), // Mock version
            content,
            createdAt: new Date().toISOString(),
        };
        mockVersions.push(newVersion);
        return newVersion;
    }
    // FIX: Added missing 'rollbackPromptToVersion' method
    async rollbackPromptToVersion(promptId, versionId) {
        const targetVersion = mockVersions.find(v => v.id === versionId && v.promptId === promptId);
        const prompt = mockPrompts.find(p => p.id === promptId);
        if (targetVersion && prompt) {
            prompt.content = targetVersion.content;
            prompt.version = targetVersion.version;
            return prompt;
        }
        return null;
    }
    // FIX: Added missing 'updatePromptMetadata' method
    async updatePromptMetadata(promptId, metadata) {
        const prompt = mockPrompts.find(p => p.id === promptId);
        if (prompt) {
            Object.assign(prompt, metadata);
            return prompt;
        }
        return null;
    }
    // FIX: Added missing 'deletePrompt' method
    async deletePrompt(promptId) {
        const index = mockPrompts.findIndex(p => p.id === promptId);
        if (index > -1) {
            mockPrompts.splice(index, 1);
            return { success: true };
        }
        return { success: false };
    }
}
exports.PromptService = PromptService;
