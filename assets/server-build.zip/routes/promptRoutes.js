"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const PromptService_1 = require("../services/PromptService");
const router = (0, express_1.Router)();
const promptService = new PromptService_1.PromptService();
// GET /api/prompts
router.get('/', async (_req, res) => {
    const prompts = await promptService.getAllPrompts();
    res.json(prompts);
});
// GET /api/prompts/:id
router.get('/:id', async (req, res) => {
    const prompt = await promptService.getPromptById(req.params.id);
    if (prompt) {
        res.json(prompt);
    }
    else {
        res.status(404).json({ message: 'Prompt not found' });
    }
});
// POST /api/prompts
router.post('/', async (req, res) => {
    const newPromptData = req.body;
    const createdPrompt = await promptService.createPrompt(newPromptData);
    res.status(201).json(createdPrompt);
});
// POST /api/prompts/:id/versions
router.post('/:id/versions', async (req, res) => {
    const { content } = req.body;
    const newVersion = await promptService.addPromptVersion(req.params.id, content);
    res.status(201).json(newVersion);
});
// POST /api/prompts/:id/rollback/:versionId
router.post('/:id/rollback/:versionId', async (req, res) => {
    const updatedPrompt = await promptService.rollbackPromptToVersion(req.params.id, req.params.versionId);
    if (updatedPrompt) {
        res.json(updatedPrompt);
    }
    else {
        res.status(404).json({ message: 'Prompt or version not found' });
    }
});
// PATCH /api/prompts/:id
router.patch('/:id', async (req, res) => {
    const updatedPrompt = await promptService.updatePromptMetadata(req.params.id, req.body);
    if (updatedPrompt) {
        res.json(updatedPrompt);
    }
    else {
        res.status(404).json({ message: 'Prompt not found' });
    }
});
// DELETE /api/prompts/:id
router.delete('/:id', async (req, res) => {
    const result = await promptService.deletePrompt(req.params.id);
    if (result.success) {
        res.status(204).send();
    }
    else {
        res.status(404).json({ message: 'Prompt not found' });
    }
});
exports.default = router;
