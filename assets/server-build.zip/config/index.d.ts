export declare const PORT: number;
export declare const OPENAI_API_KEY: string;
export declare const ANTHROPIC_API_KEY: string;
